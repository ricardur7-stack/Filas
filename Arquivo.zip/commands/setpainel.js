const { SlashCommandBuilder } = require('discord.js');
const storage = require('../storage');
const utils = require('../utils');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setpainel')
    .setDescription('Configurar o canal do painel (apenas owner)')
    .addChannelOption(opt =>
      opt.setName('canal')
        .setDescription('Canal onde o painel será enviado')
        .setRequired(true)
    ),

  async execute(interaction) {
    // Verificar se é owner
    const ownerIds = process.env.OWNER_IDS ? process.env.OWNER_IDS.split(',') : [];
    
    if (!ownerIds.includes(interaction.user.id)) {
      return await interaction.reply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Acesso Negado`,
          'Apenas o owner pode usar este comando.'
        )],
        ephemeral: true,
      });
    }

    const channel = interaction.options.getChannel('canal');

    // Verificar permissões
    if (!channel.permissionsFor(interaction.guild.members.me).has('SendMessages')) {
      return await interaction.reply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Sem Permissão`,
          'Não tenho permissão para enviar mensagens neste canal.'
        )],
        ephemeral: true,
      });
    }

    // Salvar configuração
    storage.setPanelChannel(channel.id);

    // Enviar painel no canal
    const embed = utils.createEmbed(
      `${config.emojis.token} Painel de Controle - Selfbot Manager`,
      'Bem-vindo ao painel de controle! Selecione uma opção abaixo para começar.',
      config.colors.primary,
      [
        { name: '🔑 Token', value: 'Gerenciar tokens Discord', inline: true },
        { name: '🧹 Limpeza', value: 'Limpar mensagens e amigos', inline: true },
        { name: '📞 Call', value: 'Entrar/sair de calls', inline: true },
        { name: '⚡ Progresso', value: 'Ver operações', inline: true },
      ]
    );

    const selectRow = utils.createSelectMenuRow(
      `painel_main_global`,
      'Escolha uma função...',
      [
        { label: 'Token', value: 'painel_token', description: 'Registrar e gerenciar tokens', emoji: '🔑' },
        { label: 'Limpeza', value: 'painel_limpeza', description: 'Limpar mensagens e amigos', emoji: '🧹' },
        { label: 'Call', value: 'painel_call', description: 'Entrar/sair de calls', emoji: '📞' },
        { label: 'Progresso', value: 'painel_progresso', description: 'Ver operações ativas', emoji: '⚡' },
      ]
    );

    try {
      await channel.send({
        embeds: [embed],
        components: [selectRow],
      });

      await interaction.reply({
        embeds: [utils.createSuccessEmbed(
          `${config.emojis.success} Painel Configurado`,
          `O painel foi enviado com sucesso em <#${channel.id}>!`
        )],
        ephemeral: true,
      });
    } catch (error) {
      console.error('Erro ao enviar painel:', error);
      await interaction.reply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Erro`,
          'Não foi possível enviar o painel no canal.'
        )],
        ephemeral: true,
      });
    }
  },
};

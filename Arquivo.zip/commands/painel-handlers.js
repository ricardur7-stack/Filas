const storage = require('../storage');
const utils = require('../utils');
const DiscordAPI = require('../discord-api');
const config = require('../config');
const { ActionRowBuilder, TextInputBuilder, TextInputStyle, ModalBuilder } = require('discord.js');

// ========== LIMPEZA HANDLERS ==========

async function handleLimpezaTokenSelect(interaction, userId) {
  const value = interaction.values[0];
  const tokenId = parseInt(value.split('_')[2]);
  const token = storage.getToken(userId, tokenId);

  if (!token) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'Token não encontrado.')],
      ephemeral: true,
    });
  }

  // Select para escolher tipo de limpeza
  const typeSelect = utils.createSelectMenuRow(
    `limpeza_type_${userId}_${tokenId}`,
    'Escolha o tipo de limpeza...',
    [
      { label: 'Limpeza de Servidor', value: 'limpeza_servidor', description: 'Limpar mensagens de um servidor', emoji: '🧹' },
      { label: 'Limpeza de DM', value: 'limpeza_dm', description: 'Limpar mensagens de DMs', emoji: '💬' },
      { label: 'Remover Amigos', value: 'limpeza_amigos', description: 'Remover todos os amigos', emoji: '👥' },
    ]
  );

  const embed = utils.createEmbed(
    `${config.emojis.clean} Tipo de Limpeza`,
    `Token: **${token.label}**\n\nEscolha o tipo de operação:`,
    config.colors.primary
  );

  await interaction.reply({
    embeds: [embed],
    components: [typeSelect],
    ephemeral: true,
  });
}

async function handleLimpezaTypeSelect(interaction, userId) {
  const customId = interaction.customId;
  const parts = customId.split('_');
  const tokenId = parseInt(parts[2]);
  const value = interaction.values[0];

  const token = storage.getToken(userId, tokenId);

  if (value === 'limpeza_servidor') {
    // Modal para IDs do servidor e canal
    const modal = new ModalBuilder()
      .setCustomId(`limpeza_servidor_modal_${userId}_${tokenId}`)
      .setTitle('Limpeza de Servidor');

    const guildInput = new TextInputBuilder()
      .setCustomId('guild_id')
      .setLabel('ID do Servidor')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const channelInput = new TextInputBuilder()
      .setCustomId('channel_id')
      .setLabel('ID do Canal (deixe em branco para todos)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(guildInput),
      new ActionRowBuilder().addComponents(channelInput)
    );

    await interaction.showModal(modal);
  } else if (value === 'limpeza_dm') {
    await interaction.deferReply({ ephemeral: true });

    const api = new DiscordAPI(token.token);
    const operation = storage.createOperation(userId, tokenId, 'clean_dm', {});

    storage.addOperationLog(userId, operation.id, 'Iniciando limpeza de DMs...', 'info');

    try {
      const dms = await api.getDMChannels();
      let totalDeleted = 0;

      for (const dm of dms) {
        const messages = await api.getChannelMessages(dm.id, 100);
        storage.updateOperation(userId, operation.id, {
          total: totalDeleted + messages.length,
        });

        for (const msg of messages) {
          const result = await api.deleteMessage(dm.id, msg.id);
          if (result.success) {
            totalDeleted++;
            storage.updateOperation(userId, operation.id, {
              progress: totalDeleted,
            });
          }
          await new Promise(r => setTimeout(r, 500));
        }
      }

      storage.updateOperation(userId, operation.id, {
        status: 'completed',
        progress: totalDeleted,
        total: totalDeleted,
        finishedAt: new Date().toISOString(),
      });

      storage.addOperationLog(userId, operation.id, `Limpeza concluída! ${totalDeleted} mensagens deletadas.`, 'success');

      await interaction.editReply({
        embeds: [utils.createSuccessEmbed(
          `${config.emojis.success} DMs Limpas`,
          `**${totalDeleted}** mensagens foram deletadas com sucesso!`,
          [
            { name: 'Token', value: token.label, inline: true },
            { name: 'Operação', value: `#${operation.id}`, inline: true },
          ]
        )],
      });
    } catch (error) {
      console.error('Erro:', error);
      storage.updateOperation(userId, operation.id, {
        status: 'failed',
        finishedAt: new Date().toISOString(),
      });

      await interaction.editReply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Erro`,
          error.message || 'Ocorreu um erro.'
        )],
      });
    }
  } else if (value === 'limpeza_amigos') {
    await interaction.deferReply({ ephemeral: true });

    const api = new DiscordAPI(token.token);
    const operation = storage.createOperation(userId, tokenId, 'remove_friends', {});

    storage.addOperationLog(userId, operation.id, 'Iniciando remoção de amigos...', 'info');

    try {
      const friends = await api.getFriends();
      let totalRemoved = 0;

      storage.updateOperation(userId, operation.id, {
        total: friends.length,
      });

      for (const friend of friends) {
        const result = await api.removeFriend(friend.id);
        if (result.success) {
          totalRemoved++;
          storage.updateOperation(userId, operation.id, {
            progress: totalRemoved,
          });
        }
        await new Promise(r => setTimeout(r, 500));
      }

      storage.updateOperation(userId, operation.id, {
        status: 'completed',
        progress: totalRemoved,
        total: friends.length,
        finishedAt: new Date().toISOString(),
      });

      storage.addOperationLog(userId, operation.id, `Remoção concluída! ${totalRemoved} amigos removidos.`, 'success');

      await interaction.editReply({
        embeds: [utils.createSuccessEmbed(
          `${config.emojis.success} Amigos Removidos`,
          `**${totalRemoved}** amigos foram removidos com sucesso!`,
          [
            { name: 'Token', value: token.label, inline: true },
            { name: 'Operação', value: `#${operation.id}`, inline: true },
          ]
        )],
      });
    } catch (error) {
      console.error('Erro:', error);
      storage.updateOperation(userId, operation.id, {
        status: 'failed',
        finishedAt: new Date().toISOString(),
      });

      await interaction.editReply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Erro`,
          error.message || 'Ocorreu um erro.'
        )],
      });
    }
  }
}

async function handleLimpezaServidorModal(interaction, userId) {
  const customId = interaction.customId;
  const tokenId = parseInt(customId.split('_')[3]);
  const token = storage.getToken(userId, tokenId);

  const guildId = interaction.fields.getTextInputValue('guild_id');
  const channelId = interaction.fields.getTextInputValue('channel_id') || null;

  if (!guildId) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'ID do servidor é obrigatório.')],
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const api = new DiscordAPI(token.token);
  const operation = storage.createOperation(userId, tokenId, 'clean_server', {
    guildId,
    channelId,
  });

  storage.addOperationLog(userId, operation.id, `Iniciando limpeza em servidor ${guildId}...`, 'info');

  try {
    let channels = [];
    if (channelId) {
      channels = [{ id: channelId }];
    } else {
      channels = await api.getGuildChannels(guildId);
    }

    let totalDeleted = 0;

    for (const channel of channels) {
      const messages = await api.getChannelMessages(channel.id, 100);
      storage.updateOperation(userId, operation.id, {
        total: totalDeleted + messages.length,
      });

      for (const msg of messages) {
        const result = await api.deleteMessage(channel.id, msg.id);
        if (result.success) {
          totalDeleted++;
          storage.updateOperation(userId, operation.id, {
            progress: totalDeleted,
          });
        }
        await new Promise(r => setTimeout(r, 500));
      }
    }

    storage.updateOperation(userId, operation.id, {
      status: 'completed',
      progress: totalDeleted,
      total: totalDeleted,
      finishedAt: new Date().toISOString(),
    });

    storage.addOperationLog(userId, operation.id, `Limpeza concluída! ${totalDeleted} mensagens deletadas.`, 'success');

    await interaction.editReply({
      embeds: [utils.createSuccessEmbed(
        `${config.emojis.success} Limpeza Concluída`,
        `**${totalDeleted}** mensagens foram deletadas com sucesso!`,
        [
          { name: 'Token', value: token.label, inline: true },
          { name: 'Servidor', value: `\`${guildId}\``, inline: true },
          { name: 'Operação', value: `#${operation.id}`, inline: true },
        ]
      )],
    });
  } catch (error) {
    console.error('Erro:', error);
    storage.updateOperation(userId, operation.id, {
      status: 'failed',
      finishedAt: new Date().toISOString(),
    });

    await interaction.editReply({
      embeds: [utils.createErrorEmbed(
        `${config.emojis.error} Erro`,
        error.message || 'Ocorreu um erro.'
      )],
    });
  }
}

// ========== CALL HANDLERS ==========

async function handleCallTokenSelect(interaction, userId) {
  const value = interaction.values[0];
  const tokenId = parseInt(value.split('_')[2]);
  const token = storage.getToken(userId, tokenId);

  if (!token) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'Token não encontrado.')],
      ephemeral: true,
    });
  }

  // Select para escolher ação
  const actionSelect = utils.createSelectMenuRow(
    `call_action_${userId}_${tokenId}`,
    'Escolha uma ação...',
    [
      { label: 'Entrar em Call', value: 'call_join', description: 'Conectar a um canal de voz', emoji: '📞' },
      { label: 'Sair de Call', value: 'call_leave', description: 'Desconectar de um canal', emoji: '🚪' },
    ]
  );

  const embed = utils.createEmbed(
    `${config.emojis.call} Gerenciador de Calls`,
    `Token: **${token.label}**\n\nEscolha uma ação:`,
    config.colors.primary
  );

  await interaction.reply({
    embeds: [embed],
    components: [actionSelect],
    ephemeral: true,
  });
}

async function handleCallActionSelect(interaction, userId) {
  const customId = interaction.customId;
  const parts = customId.split('_');
  const tokenId = parseInt(parts[2]);
  const value = interaction.values[0];

  const token = storage.getToken(userId, tokenId);

  if (value === 'call_join') {
    // Modal para IDs do servidor e canal
    const modal = new ModalBuilder()
      .setCustomId(`call_join_modal_${userId}_${tokenId}`)
      .setTitle('Entrar em Call');

    const guildInput = new TextInputBuilder()
      .setCustomId('guild_id')
      .setLabel('ID do Servidor')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const channelInput = new TextInputBuilder()
      .setCustomId('channel_id')
      .setLabel('ID do Canal de Voz')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(guildInput),
      new ActionRowBuilder().addComponents(channelInput)
    );

    await interaction.showModal(modal);
  } else if (value === 'call_leave') {
    // Modal para ID do servidor
    const modal = new ModalBuilder()
      .setCustomId(`call_leave_modal_${userId}_${tokenId}`)
      .setTitle('Sair de Call');

    const guildInput = new TextInputBuilder()
      .setCustomId('guild_id')
      .setLabel('ID do Servidor')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(guildInput)
    );

    await interaction.showModal(modal);
  }
}

async function handleCallJoinModal(interaction, userId) {
  const customId = interaction.customId;
  const tokenId = parseInt(customId.split('_')[3]);
  const token = storage.getToken(userId, tokenId);

  const guildId = interaction.fields.getTextInputValue('guild_id');
  const channelId = interaction.fields.getTextInputValue('channel_id');

  if (!guildId || !channelId) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'Todos os campos são obrigatórios.')],
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const api = new DiscordAPI(token.token);
  const operation = storage.createOperation(userId, tokenId, 'join_call', {
    guildId,
    channelId,
  });

  storage.addOperationLog(userId, operation.id, `Conectando ao canal ${channelId}...`, 'info');

  try {
    const result = await api.joinVoiceChannel(guildId, channelId);

    if (result.success) {
      storage.updateOperation(userId, operation.id, {
        status: 'completed',
        progress: 1,
        total: 1,
        finishedAt: new Date().toISOString(),
      });

      storage.addOperationLog(userId, operation.id, 'Conectado com sucesso!', 'success');

      await interaction.editReply({
        embeds: [utils.createSuccessEmbed(
          `${config.emojis.call} Conectado ao Call`,
          `A conta foi conectada ao canal de voz com sucesso!`,
          [
            { name: 'Token', value: token.label, inline: true },
            { name: 'Servidor', value: `\`${guildId}\``, inline: true },
            { name: 'Canal', value: `\`${channelId}\``, inline: true },
          ]
        )],
      });
    } else {
      storage.updateOperation(userId, operation.id, {
        status: 'failed',
        finishedAt: new Date().toISOString(),
      });

      await interaction.editReply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Erro ao Conectar`,
          result.error || 'Não foi possível conectar ao canal de voz.'
        )],
      });
    }
  } catch (error) {
    console.error('Erro:', error);
    storage.updateOperation(userId, operation.id, {
      status: 'failed',
      finishedAt: new Date().toISOString(),
    });

    await interaction.editReply({
      embeds: [utils.createErrorEmbed(
        `${config.emojis.error} Erro`,
        error.message || 'Ocorreu um erro.'
      )],
    });
  }
}

async function handleCallLeaveModal(interaction, userId) {
  const customId = interaction.customId;
  const tokenId = parseInt(customId.split('_')[3]);
  const token = storage.getToken(userId, tokenId);

  const guildId = interaction.fields.getTextInputValue('guild_id');

  if (!guildId) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'ID do servidor é obrigatório.')],
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  const api = new DiscordAPI(token.token);
  const operation = storage.createOperation(userId, tokenId, 'leave_call', {
    guildId,
  });

  storage.addOperationLog(userId, operation.id, `Desconectando do canal...`, 'info');

  try {
    const result = await api.leaveVoiceChannel(guildId);

    if (result.success) {
      storage.updateOperation(userId, operation.id, {
        status: 'completed',
        progress: 1,
        total: 1,
        finishedAt: new Date().toISOString(),
      });

      storage.addOperationLog(userId, operation.id, 'Desconectado com sucesso!', 'success');

      await interaction.editReply({
        embeds: [utils.createSuccessEmbed(
          `${config.emojis.call} Desconectado do Call`,
          `A conta foi desconectada do canal de voz com sucesso!`,
          [
            { name: 'Token', value: token.label, inline: true },
            { name: 'Servidor', value: `\`${guildId}\``, inline: true },
          ]
        )],
      });
    } else {
      storage.updateOperation(userId, operation.id, {
        status: 'failed',
        finishedAt: new Date().toISOString(),
      });

      await interaction.editReply({
        embeds: [utils.createErrorEmbed(
          `${config.emojis.error} Erro ao Desconectar`,
          result.error || 'Não foi possível desconectar do canal de voz.'
        )],
      });
    }
  } catch (error) {
    console.error('Erro:', error);
    storage.updateOperation(userId, operation.id, {
      status: 'failed',
      finishedAt: new Date().toISOString(),
    });

    await interaction.editReply({
      embeds: [utils.createErrorEmbed(
        `${config.emojis.error} Erro`,
        error.message || 'Ocorreu um erro.'
      )],
    });
  }
}

// ========== PROGRESSO HANDLERS ==========

async function handleProgressoButton(interaction, userId) {
  const customId = interaction.customId;

  if (customId === `progress_refresh_${userId}`) {
    const operations = storage.getOperations(userId);
    const activeOps = operations.filter(o => o.status === 'pending' || o.status === 'running');

    if (activeOps.length === 0) {
      return await interaction.reply({
        embeds: [utils.createInfoEmbed(
          `${config.emojis.progress} Progresso`,
          'Nenhuma operação ativa no momento.'
        )],
        ephemeral: true,
      });
    }

    let description = `**${config.emojis.loading} Operações Ativas:**\n`;
    activeOps.forEach(op => {
      const progress = op.total > 0 ? Math.round((op.progress / op.total) * 100) : 0;
      const bar = createProgressBar(progress);
      description += `• ${utils.formatOperationType(op.type)} - ${bar} ${progress}%\n`;
    });

    const embed = utils.createEmbed(
      `${config.emojis.progress} Progresso Atualizado`,
      description,
      config.colors.info
    );

    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  } else if (customId === `progress_history_${userId}`) {
    const operations = storage.getOperations(userId);
    const completedOps = operations.filter(o => o.status === 'completed' || o.status === 'failed' || o.status === 'cancelled');

    if (completedOps.length === 0) {
      return await interaction.reply({
        embeds: [utils.createInfoEmbed(
          `${config.emojis.progress} Histórico`,
          'Nenhuma operação concluída ainda.'
        )],
        ephemeral: true,
      });
    }

    const fields = completedOps.slice(0, 10).map(op => {
      const token = storage.getToken(userId, op.tokenId);
      return {
        name: `${utils.formatOperationType(op.type)} #${op.id}`,
        value: `**Token:** ${token?.label || 'Desconhecido'}\n**Status:** ${utils.formatOperationStatus(op.status)}\n**Progresso:** ${op.progress}/${op.total}\n**Data:** ${new Date(op.startedAt).toLocaleString('pt-BR')}`,
        inline: false,
      };
    });

    const embed = utils.createEmbed(
      `${config.emojis.progress} Histórico de Operações`,
      `Mostrando **${Math.min(10, completedOps.length)}** de **${completedOps.length}** operações.`,
      config.colors.info,
      fields
    );

    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  }
}

function createProgressBar(percentage) {
  const filled = Math.round(percentage / 10);
  const empty = 10 - filled;
  return `[${'█'.repeat(filled)}${'░'.repeat(empty)}]`;
}

module.exports = {
  handleLimpezaTokenSelect,
  handleLimpezaTypeSelect,
  handleLimpezaServidorModal,
  handleCallTokenSelect,
  handleCallActionSelect,
  handleCallJoinModal,
  handleCallLeaveModal,
  handleProgressoButton,
};

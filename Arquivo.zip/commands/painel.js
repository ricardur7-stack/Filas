const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const storage = require('../storage');
const utils = require('../utils');
const DiscordAPI = require('../discord-api');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('painel')
    .setDescription('Abrir o painel de controle do selfbot'),

  async execute(interaction) {
    const userId = interaction.user.id;

    // Criar embed principal
    const embed = utils.createEmbed(
      `${config.emojis.token} Painel de Controle - Selfbot Manager`,
      'Bem-vindo ao painel de controle! Selecione uma opção abaixo para começar.',
      config.colors.primary,
      [
        { name: '🔑 Token', value: 'Gerenciar tokens Discord', inline: true },
        { name: '🧹 Limpeza', value: 'Limpar mensagens e amigos', inline: true },
        { name: '📞 Call', value: 'Entrar/sair de calls', inline: true },
        { name: '⚡ Progresso', value: 'Ver operações', inline: true },
      ]
    );

    // Select menu principal
    const selectRow = utils.createSelectMenuRow(
      `painel_main_${userId}`,
      'Escolha uma função...',
      [
        { label: 'Token', value: 'painel_token', description: 'Registrar e gerenciar tokens', emoji: '🔑' },
        { label: 'Limpeza', value: 'painel_limpeza', description: 'Limpar mensagens e amigos', emoji: '🧹' },
        { label: 'Call', value: 'painel_call', description: 'Entrar/sair de calls', emoji: '📞' },
        { label: 'Progresso', value: 'painel_progresso', description: 'Ver operações ativas', emoji: '⚡' },
      ]
    );

    await interaction.reply({
      embeds: [embed],
      components: [selectRow],
      ephemeral: false,
    });
  },

  async handleSelectMenu(interaction, userId) {
    const value = interaction.values[0];

    if (value === 'painel_token') {
      await handleTokenPanel(interaction, userId);
    } else if (value === 'painel_limpeza') {
      await handleLimpezaPanel(interaction, userId);
    } else if (value === 'painel_call') {
      await handleCallPanel(interaction, userId);
    } else if (value === 'painel_progresso') {
      await handleProgressoPanel(interaction, userId);
    }
  },
};

// ========== TOKEN PANEL ==========

async function handleTokenPanel(interaction, userId) {
  const tokens = storage.getTokens(userId);

  // Select para escolher ação
  const actionSelect = utils.createSelectMenuRow(
    `token_action_${userId}`,
    'Escolha uma ação...',
    [
      { label: 'Adicionar Token', value: 'token_add', description: 'Registrar novo token', emoji: '➕' },
      { label: 'Listar Tokens', value: 'token_list', description: `Ver ${tokens.length} token(s)`, emoji: '📋' },
      { label: 'Remover Token', value: 'token_remove', description: 'Deletar um token', emoji: '🗑️' },
    ]
  );

  const embed = utils.createEmbed(
    `${config.emojis.token} Gerenciador de Tokens`,
    `Você tem **${tokens.length}** token(s) registrado(s).`,
    config.colors.primary
  );

  await interaction.reply({
    embeds: [embed],
    components: [actionSelect],
    ephemeral: true,
  });
}

// ========== LIMPEZA PANEL ==========

async function handleLimpezaPanel(interaction, userId) {
  const tokens = storage.getTokens(userId).filter(t => t.status === 'valid');

  if (tokens.length === 0) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed(
        'Sem Tokens Válidos',
        'Você precisa registrar e validar um token primeiro.'
      )],
      ephemeral: true,
    });
  }

  // Select para escolher token
  const tokenSelect = utils.createSelectMenuRow(
    `limpeza_token_${userId}`,
    'Selecione um token...',
    tokens.map(t => ({
      label: t.label,
      value: `limpeza_token_${t.id}`,
      description: `@${t.discordUsername || 'Desconhecido'}`,
      emoji: '🔑',
    }))
  );

  const embed = utils.createEmbed(
    `${config.emojis.clean} Operações de Limpeza`,
    'Selecione um token para começar.',
    config.colors.primary
  );

  await interaction.reply({
    embeds: [embed],
    components: [tokenSelect],
    ephemeral: true,
  });
}

// ========== CALL PANEL ==========

async function handleCallPanel(interaction, userId) {
  const tokens = storage.getTokens(userId).filter(t => t.status === 'valid');

  if (tokens.length === 0) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed(
        'Sem Tokens Válidos',
        'Você precisa registrar e validar um token primeiro.'
      )],
      ephemeral: true,
    });
  }

  // Select para escolher token
  const tokenSelect = utils.createSelectMenuRow(
    `call_token_${userId}`,
    'Selecione um token...',
    tokens.map(t => ({
      label: t.label,
      value: `call_token_${t.id}`,
      description: `@${t.discordUsername || 'Desconhecido'}`,
      emoji: '📞',
    }))
  );

  const embed = utils.createEmbed(
    `${config.emojis.call} Gerenciador de Calls`,
    'Selecione um token para entrar/sair de calls.',
    config.colors.primary
  );

  await interaction.reply({
    embeds: [embed],
    components: [tokenSelect],
    ephemeral: true,
  });
}

// ========== PROGRESSO PANEL ==========

async function handleProgressoPanel(interaction, userId) {
  const operations = storage.getOperations(userId);
  const activeOps = operations.filter(o => o.status === 'pending' || o.status === 'running');
  const completedOps = operations.filter(o => o.status === 'completed' || o.status === 'failed');

  let description = '';

  if (activeOps.length > 0) {
    description += `**${config.emojis.loading} Ativas (${activeOps.length}):**\n`;
    activeOps.slice(0, 3).forEach(op => {
      const progress = op.total > 0 ? Math.round((op.progress / op.total) * 100) : 0;
      description += `• ${utils.formatOperationType(op.type)} - ${progress}%\n`;
    });
  } else {
    description += `**${config.emojis.loading} Nenhuma operação ativa**\n`;
  }

  description += `\n**${config.emojis.success} Histórico (${completedOps.length}):**\n`;
  if (completedOps.length === 0) {
    description += 'Nenhuma operação no histórico.';
  } else {
    completedOps.slice(0, 3).forEach(op => {
      description += `• ${utils.formatOperationType(op.type)} - ${utils.formatOperationStatus(op.status)}\n`;
    });
  }

  const embed = utils.createEmbed(
    `${config.emojis.progress} Progresso das Operações`,
    description,
    config.colors.info
  );

  const buttons = [
    utils.createSecondaryButton('🔄 Atualizar', `progress_refresh_${userId}`),
    utils.createSecondaryButton('📋 Histórico Completo', `progress_history_${userId}`),
  ];

  await interaction.reply({
    embeds: [embed],
    components: [utils.createButtonRow(...buttons)],
    ephemeral: true,
  });
}

// ========== TOKEN ACTIONS ==========

module.exports.handleTokenAction = async function(interaction, userId) {
  const value = interaction.values[0];

  if (value === 'token_add') {
    // Modal para adicionar token
    const modal = new ModalBuilder()
      .setCustomId(`token_add_modal_${userId}`)
      .setTitle('Adicionar Token Discord');

    const labelInput = new TextInputBuilder()
      .setCustomId('token_label')
      .setLabel('Identificador (ex: Conta Principal)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const tokenInput = new TextInputBuilder()
      .setCustomId('token_value')
      .setLabel('USER TOKEN (selfbot) - NAO bot token')
      .setPlaceholder('Cole seu user token aqui (2 partes separadas por ponto)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(labelInput),
      new ActionRowBuilder().addComponents(tokenInput)
    );

    await interaction.showModal(modal);
  } else if (value === 'token_list') {
    const tokens = storage.getTokens(userId);

    if (tokens.length === 0) {
      return await interaction.reply({
        embeds: [utils.createInfoEmbed(
          `${config.emojis.token} Tokens`,
          'Nenhum token registrado ainda.'
        )],
        ephemeral: true,
      });
    }

    const fields = tokens.map(t => ({
      name: `${config.emojis.token} ${t.label}`,
      value: `**Status:** ${utils.formatTokenStatus(t.status)}\n**Usuário:** ${t.discordUsername || 'Não validado'}`,
      inline: false,
    }));

    const embed = utils.createEmbed(
      `${config.emojis.token} Tokens Registrados`,
      `Total: **${tokens.length}**`,
      config.colors.primary,
      fields
    );

    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  } else if (value === 'token_remove') {
    const tokens = storage.getTokens(userId);

    if (tokens.length === 0) {
      return await interaction.reply({
        embeds: [utils.createErrorEmbed(
          'Nenhum Token',
          'Você não tem tokens registrados.'
        )],
        ephemeral: true,
      });
    }

    const options = tokens.map(t => ({
      label: t.label,
      value: `token_remove_select_${t.id}`,
      description: `${utils.formatTokenStatus(t.status)}`,
      emoji: '🗑️',
    }));

    const selectRow = utils.createSelectMenuRow(
      `token_remove_select_${userId}`,
      'Selecione um token para remover...',
      options
    );

    await interaction.reply({
      content: 'Selecione o token que deseja remover:',
      components: [selectRow],
      ephemeral: true,
    });
  }
};

module.exports.handleTokenAddModal = async function(interaction, userId) {
  const label = interaction.fields.getTextInputValue('token_label');
  const token = interaction.fields.getTextInputValue('token_value').trim();

  if (!label || !token) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'Por favor, preencha todos os campos.')],
      ephemeral: true,
    });
  }

  // Validacao prvia do formato
  const parts = token.split('.');
  if (parts.length === 3) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed(
        `${config.emojis.error} BOT TOKEN DETECTADO!`,
        '❌ Voce esta tentando registrar um **BOT TOKEN**!\n\nEste bot precisa de um **USER TOKEN (selfbot)** para funcionar.\n\n**Como obter um user token:**\n1. Abra Discord no navegador\n2. Pressione F12 (DevTools)\n3. Va para Application → Cookies → discord.com\n4. Procure por "token"\n5. Copie o valor (sem aspas)\n\n**Aviso:** Nunca compartilhe seu token com ninguem!'
      )],
      ephemeral: true,
    });
  }

  const api = new DiscordAPI(token);
  const validation = await api.validateToken();

  if (!validation.valid) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed(
        `${config.emojis.error} Token Invalido`,
        validation.error || 'O token fornecido eh invalido.'
      )],
      ephemeral: true,
    });
  }

  const newToken = storage.addToken(userId, label, token);
  storage.updateTokenStatus(userId, newToken.id, 'valid', validation.username, validation.id);

  await interaction.reply({
    embeds: [utils.createSuccessEmbed(
      `${config.emojis.success} Token Registrado`,
      `O token foi registrado com sucesso!`,
      [
        { name: 'Identificador', value: label, inline: true },
        { name: 'Usuário', value: `${validation.username}#${validation.discriminator}`, inline: true },
      ]
    )],
    ephemeral: true,
  });
};

module.exports.handleTokenRemoveSelect = async function(interaction, userId) {
  const value = interaction.values[0];
  const tokenId = parseInt(value.split('_')[3]);
  const token = storage.getToken(userId, tokenId);

  if (!token) {
    return await interaction.reply({
      embeds: [utils.createErrorEmbed('Erro', 'Token não encontrado.')],
      ephemeral: true,
    });
  }

  storage.removeToken(userId, tokenId);

  await interaction.reply({
    embeds: [utils.createSuccessEmbed(
      `${config.emojis.success} Token Removido`,
      `O token **${token.label}** foi removido com sucesso.`
    )],
    ephemeral: true,
  });
};
